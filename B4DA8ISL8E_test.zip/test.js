let timer;
let timerLeft = 1500;
let running = false;

function updateDisplay() {
    let minutes = Math.floor(timerLeft / 60).toString().padStart(2, '0');
    let seconds = (timerLeft % 60).toString().padStart(2, '0');
    document.getElementById('timer').textContent = `${minutes}:${seconds}`;

}

document.getElementById('start').addEventListener('click', () => {
    if (!running) {
        running = true;
        timer = setInterval(() => {
            if (timerLeft > 0) {
                timerLeft--;
                updateDisplay();
            } else {
                clearInterval(timer);
            }
        }, 1000);
    }
});

document.getElementById('reset').addEventListener('click', () => {
    timeLeft = 1500;
    updateDisplay();
});

document.getElementById('stop').addEventListener('click', () => {
    clearInterval(timer);
    timeLeft = 1500;
    updateDisplay();
    running = false;
});

document.getElementById('shortBreak').addEventListener('click', () => {
    timeLeft = 300;
    updateDisplay();
});

document.getElementById('longBreak').addEventListener('click', () => {
    timeLeft = 900;
    updateDisplay();
});

updateDisplay();